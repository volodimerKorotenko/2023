#include <stdio.h>
#include <stdlib.h>
#include "dk_tool.h"
#include "dk_tool.c"

int main()
{
    int rows, cols;

    printf("Enter number of rows: ");
    scanf("%d", &rows);

    printf("Enter number of columns: ");
    scanf("%d", &cols);

    int **A = (int **)malloc(rows * sizeof(int *));
    int **B = (int **)malloc(rows * sizeof(int *));
    int **C = (int **)malloc(rows * sizeof(int *));

    for (int i = 0; i < rows; i++)
    {
        A[i] = (int *)malloc(cols * sizeof(int));
        B[i] = (int *)malloc(cols * sizeof(int));
        C[i] = (int *)malloc(cols * sizeof(int));
    }

    printf("Enter values for matrix A:\n");
    fill_matrix(A, rows, cols);

    printf("Enter values for matrix B:\n");
    fill_matrix(B, rows, cols);

    add_matrices(A, B, C, rows, cols);

    printf("Result:\n");
    print_matrix(C, rows, cols);

    for (int i = 0; i < rows; i++)
    {
        free(A[i]);
        free(B[i]);
        free(C[i]);
    }

    free(A);
    free(B);
    free(C);

    return 0;
}