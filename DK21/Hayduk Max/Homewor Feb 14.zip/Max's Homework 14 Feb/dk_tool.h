#ifndef DK_TOOL_H_INCLUDED
#define DK_TOOL_H_INCLUDED

void add_matrices(int **A, int **B, int **C, int rows, int cols);
void fill_matrix(int **matrix, int rows, int cols);
void print_matrix(int **matrix, int rows, int cols);

#endif // DK_TOOL_H_INCLUDED