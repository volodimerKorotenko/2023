#include <stdio.h>
#include <stdlib.h>

struct Point {
    float x;
    float y;
};

struct Square {
    struct Point p1;
    struct Point p2;
    struct Point p3;
    struct Point p4;
};

struct Square* createSquare(struct Point* points) {
    if (!points) return NULL;

    struct Square* square = (struct Square*) malloc(sizeof(struct Square));
    if (!square) return NULL;

    square->p1 = points[0];
    square->p2 = points[1];
    square->p3 = points[2];
    square->p4 = points[3];

    return square;
}

struct Square* createSquareFromCoords(float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4) {
    struct Point points[4] = {{x1, y1}, {x2, y2}, {x3, y3}, {x4, y4}};
    return createSquare(points);
}

struct Square* createSquareFromList(struct Point* pointList) {
    if (!pointList) return NULL;

    return createSquare(pointList);
}

void destroySquare(struct Square* square) {
    free(square);
}

int isValidPoint(struct Point* point) {
    if (!point) return 0;

    return 1;
}

int isValidPointList(struct Point* pointList, int numPoints) {
    if (!pointList || numPoints != 4) return 0;

    return 1;
}

void printSquare(struct Square* square) {
    if (!square) return;

    printf("Square:\n");
    printf("Point 1: (%f, %f)\n", square->p1.x, square->p1.y);
    printf("Point 2: (%f, %f)\n", square->p2.x, square->p2.y);
    printf("Point 3: (%f, %f)\n", square->p3.x, square->p3.y);
    printf("Point 4: (%f, %f)\n", square->p4.x, square->p4.y);
}

int main() {
    struct Point points[4] = {{0, 0}, {0, 2}, {2, 2}, {2, 0}};
    struct Square* square = createSquare(points);
    printSquare(square);
    destroySquare(square);

    struct Point pointList[4] = {{0, 0}, {0, 2}, {2, 2}, {2, 0}};
    struct Square* square2 = createSquareFromList(pointList);
    printSquare(square2);
    destroySquare(square2);

    struct Square* square3 = createSquareFromCoords(0, 0, 0, 2, 2, 2, 2, 0);
    printSquare(square3);
    destroySquare(square3);

    return 0;
}