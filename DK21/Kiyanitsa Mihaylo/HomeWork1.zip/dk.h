#ifndef COUNT_SUBSTRING_H
#define COUNT_SUBSTRING_H

int countSubstring(const char *str, const char *substr);

#endif /* COUNT_SUBSTRING_H */
